﻿using System;
using System.Collections.Generic;

public delegate void RecipeCaloriesExceededEventHandler(string recipeName, double totalCalories);

public class Ingredient
{
    public string Name { get; set; }
    public double Quantity { get; set; }
    public string UnitOfMeasurement { get; set; }
    public double Calories { get; set; }
    public string FoodGroup { get; set; }
}

public class Recipe
{
    public string NameOfRecipe { get; set; }
    public List<Ingredient> Ingredients { get; set; }
    public List<string> CookingSteps { get; set; }

    public event RecipeCaloriesExceededEventHandler CaloriesExceeded;

    public Recipe()
    {
        Ingredients = new List<Ingredient>();
        CookingSteps = new List<string>();
    }

    public void CaptureIngredientDetails()//Method to capture ingredient details
    {
        Console.WriteLine("What is the name of your recipe?");
        NameOfRecipe = Console.ReadLine();

        Console.WriteLine($"How many ingredients are needed to prepare the {NameOfRecipe}?");
        int numIngredients = Convert.ToInt32(Console.ReadLine());

        double totalCalories = 0;

        for (int i = 0; i < numIngredients; i++)
        {
            Ingredient ingredient = new Ingredient();

            Console.WriteLine($"Enter the name for ingredient {i + 1}:");
            ingredient.Name = Console.ReadLine();

            Console.WriteLine($"Enter the quantity of {ingredient.Name}:");
            ingredient.Quantity = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine($"Enter the unit of measurement for {ingredient.Name}:");
            ingredient.UnitOfMeasurement = Console.ReadLine();

            Console.WriteLine($"Enter the number of calories for {ingredient.Name}:");
            ingredient.Calories = Convert.ToDouble(Console.ReadLine());

            totalCalories += ingredient.Calories;

            Console.WriteLine($"Enter the food group for {ingredient.Name}:");
            ingredient.FoodGroup = Console.ReadLine();

            Ingredients.Add(ingredient);
        }

        if (totalCalories > 300 && CaloriesExceeded != null)
        {
            CaloriesExceeded(NameOfRecipe, totalCalories);
        }

        Console.WriteLine($"You have added {numIngredients} ingredients to your recipe!");
    }

    public void AddSteps()//Method to add steps
    {
        Console.WriteLine($"How many steps are there in {NameOfRecipe}?");
        int numSteps = Convert.ToInt32(Console.ReadLine());

        for (int i = 0; i < numSteps; i++)
        {
            Console.WriteLine($"Enter step {i + 1}:");
            string step = Console.ReadLine();
            CookingSteps.Add(step);
        }

        Console.WriteLine($"You have added {numSteps} steps to your recipe!");
    }

    public void DisplayIngredientsAndSteps() //Method to display full recipe with ingredients and steps
    {
        Console.WriteLine($"Ingredients for {NameOfRecipe}:");
        foreach (var ingredient in Ingredients)
        {
            Console.WriteLine($"{ingredient.Name} - {ingredient.Quantity} {ingredient.UnitOfMeasurement} - {ingredient.Calories} calories - Food Group: {ingredient.FoodGroup}");
        }

        Console.WriteLine($"Steps to prepare {NameOfRecipe}:");
        foreach (var step in CookingSteps)
        {
            Console.WriteLine(step);
        }
    }

    public void ScaleRecipe(double factor) //Method to scale recipe
    {
        for (int i = 0; i < Ingredients.Count; i++)
        {
            Ingredients[i].Quantity *= factor;
        }
        Console.WriteLine($"Recipe scaled by a factor of {factor}");
    }

    public void ResetQuantities(double factor) //Method to reset quantities
    {
        if (factor == 0)
        {
            Console.WriteLine("Error: Factor cannot be zero.");
            return;
        }

        for (int i = 0; i < Ingredients.Count; i++)
        {
            Ingredients[i].Quantity /= factor;
        }

        Console.WriteLine($"Quantities reset to original values (scaled by 1/{factor}).");
    }
}

class Program
{
    private static List<Recipe> recipes = new List<Recipe>();

    private static void Main(string[] args)
    {
        bool exit = false;

        while (!exit)
        {
            Console.WriteLine("________________________________________________");
            Console.WriteLine("                    MENU                        ");
            Console.WriteLine("________________________________________________");

            Console.WriteLine("1.) Add a new recipe.");
            Console.WriteLine("2.) Display all recipes.");
            Console.WriteLine("3.) Scale a recipe.");
            Console.WriteLine("4.) Reset quantities of a recipe.");
            Console.WriteLine("5.) Exit");

            Console.WriteLine("________________________________________________");
            Console.WriteLine("             Choose an option!                  ");
            Console.WriteLine("________________________________________________");

            int menuChoice = Convert.ToInt32(Console.ReadLine());

            switch (menuChoice)
            {
                case 1:
                    Recipe newRecipe = new Recipe();
                    newRecipe.CaloriesExceeded += HandleCaloriesExceeded;
                    newRecipe.CaptureIngredientDetails();
                    newRecipe.AddSteps();
                    recipes.Add(newRecipe);
                    break;

                case 2:
                    DisplayAllRecipes();
                    break;

                case 3:
                    ScaleRecipe();
                    break;

                case 4:
                    ResetQuantities();
                    break;

                case 5:
                    exit = true;
                    break;

                default:
                    Console.WriteLine("Invalid input! Please enter a valid number.");
                    break;
            }
        }
    }

    private static void DisplayAllRecipes()//Method to display recipes
    {
        Console.WriteLine("________________________________________________");
        Console.WriteLine("            All Recipes Available               ");
        Console.WriteLine("________________________________________________");

        for (int i = 0; i < recipes.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {recipes[i].NameOfRecipe}");
        }

        Console.WriteLine("________________________________________________");
        Console.WriteLine("Select a recipe to display ingredients and steps:");
        int selectedRecipeIndex = Convert.ToInt32(Console.ReadLine());

        if (selectedRecipeIndex > 0 && selectedRecipeIndex <= recipes.Count)
        {
            recipes[selectedRecipeIndex - 1].DisplayIngredientsAndSteps();
        }
        else
        {
            Console.WriteLine("Invalid recipe index.");
        }
    }

    private static void ScaleRecipe()//Method to scale recipe
    {
        Console.WriteLine("Enter the index of the recipe to scale:");
        int recipeIndex = Convert.ToInt32(Console.ReadLine());

        if (recipeIndex > 0 && recipeIndex <= recipes.Count)
        {
            Console.WriteLine("Enter the scaling factor (0.5, 2, or 3): ");
            double factor = Convert.ToDouble(Console.ReadLine());
            recipes[recipeIndex - 1].ScaleRecipe(factor);
        }
        else
        {
            Console.WriteLine("Invalid recipe index.");
        }
    }

    private static void ResetQuantities()//Method to reset quantities
    {
        Console.WriteLine("Enter the index of the recipe to reset quantities:");
        int recipeIndex = Convert.ToInt32(Console.ReadLine());

        if (recipeIndex > 0 && recipeIndex <= recipes.Count)
        {
            Console.WriteLine("Enter the scaling factor (0.5, 2, or 3): ");
            double factor = Convert.ToDouble(Console.ReadLine());
            recipes[recipeIndex - 1].ResetQuantities(factor);
        }
        else
        {
            Console.WriteLine("Invalid recipe index.");
        }
    }

    private static void HandleCaloriesExceeded(string recipeName, double totalCalories)//Method to display notification for calories exceeding 300
    {
        Console.WriteLine($"Warning: The total calories of recipe '{recipeName}' ({totalCalories} calories) exceeds 300 Calories!");
    }
}
